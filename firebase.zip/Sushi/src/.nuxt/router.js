import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _3af8b50e = () => import('..\\pages\\iparques\\index.vue' /* webpackChunkName: "pages_iparques_index" */).then(m => m.default || m)
const _038890d4 = () => import('..\\pages\\users\\index.vue' /* webpackChunkName: "pages_users_index" */).then(m => m.default || m)
const _e17ad496 = () => import('..\\pages\\admin.vue' /* webpackChunkName: "pages_admin" */).then(m => m.default || m)
const _3e1b66f3 = () => import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */).then(m => m.default || m)
const _3bb39c5e = () => import('..\\pages\\indexProduto.vue' /* webpackChunkName: "pages_indexProduto" */).then(m => m.default || m)
const _7a9b2657 = () => import('..\\pages\\imedicos\\index.vue' /* webpackChunkName: "pages_imedicos_index" */).then(m => m.default || m)
const _6336d4a7 = () => import('..\\pages\\cafe.vue' /* webpackChunkName: "pages_cafe" */).then(m => m.default || m)
const _5bba8523 = () => import('..\\pages\\imedicos\\_id\\index.vue' /* webpackChunkName: "pages_imedicos__id_index" */).then(m => m.default || m)
const _43aca2f6 = () => import('..\\pages\\iparques\\_id.vue' /* webpackChunkName: "pages_iparques__id" */).then(m => m.default || m)
const _1becb83c = () => import('..\\pages\\users\\_id.vue' /* webpackChunkName: "pages_users__id" */).then(m => m.default || m)
const _15ed20c6 = () => import('..\\pages\\users\\_id\\index.vue' /* webpackChunkName: "pages_users__id_index" */).then(m => m.default || m)
const _5dd341b8 = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/iparques",
			component: _3af8b50e,
			name: "iparques"
		},
		{
			path: "/users",
			component: _038890d4,
			name: "users"
		},
		{
			path: "/admin",
			component: _e17ad496,
			name: "admin"
		},
		{
			path: "/about",
			component: _3e1b66f3,
			name: "about"
		},
		{
			path: "/indexProduto",
			component: _3bb39c5e,
			name: "indexProduto"
		},
		{
			path: "/imedicos",
			component: _7a9b2657,
			name: "imedicos"
		},
		{
			path: "/cafe",
			component: _6336d4a7,
			name: "cafe"
		},
		{
			path: "/imedicos/:id",
			component: _5bba8523,
			name: "imedicos-id"
		},
		{
			path: "/iparques/:id",
			component: _43aca2f6,
			name: "iparques-id"
		},
		{
			path: "/users/:id",
			component: _1becb83c,
			children: [
				{
					path: "",
					component: _15ed20c6,
					name: "users-id"
				}
			]
		},
		{
			path: "/",
			component: _5dd341b8,
			name: "index"
		}
    ],
    
    
    fallback: false
  })
}
