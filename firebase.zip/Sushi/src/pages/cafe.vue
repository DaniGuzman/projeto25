<template>
<div>
  <h1>Cafe do Vale </h1>
  <h2>agora</h2>
</div>
</template>
