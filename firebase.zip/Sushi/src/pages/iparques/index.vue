<template>
  <h1>Parques</h1>
</template>
